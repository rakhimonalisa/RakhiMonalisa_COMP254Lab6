package Lab6;

import java.util.ArrayList;


public class ChainHashMap<K,V> extends AbstractHashMap<K,V> {
  
  private UnsortedTableMap<K,V>[] table;   
  
  
  public ChainHashMap() { super(); }

  
  public ChainHashMap(int cap) { super(cap); }

 
  public ChainHashMap(int cap, int p) { super(cap, p); }

  
  @Override
  @SuppressWarnings({"unchecked"})
  protected void createTable() {
    table = (UnsortedTableMap<K,V>[]) new UnsortedTableMap[capacity];
  }

  
  @Override
  protected V bucketGet(int h, K k) {
    UnsortedTableMap<K,V> bucket = table[h];
    if (bucket == null) return null;
    return bucket.get(k);
  }

 
  @Override
  protected V bucketPut(int h, K k, V v) {
    UnsortedTableMap<K,V> bucket = table[h];
    if (bucket == null)
      bucket = table[h] = new UnsortedTableMap<>();
    int oldSize = bucket.size();
    V answer = bucket.put(k,v);
    n += (bucket.size() - oldSize);   
    return answer;
  }

  
  @Override
  protected V bucketRemove(int h, K k) {
    UnsortedTableMap<K,V> bucket = table[h];
    if (bucket == null) return null;
    int oldSize = bucket.size();
    V answer = bucket.remove(k);
    n -= (oldSize - bucket.size());   
    return answer;
  }

  
  @Override
  public Iterable<Entry<K,V>> entrySet() {
    ArrayList<Entry<K,V>> buffer = new ArrayList<>();
    for (int h=0; h < capacity; h++)
      if (table[h] != null)
        for (Entry<K,V> entry : table[h].entrySet())
          buffer.add(entry);
    return buffer;
  }
  
  
  
  public static void main(String[] args) {
		ChainHashMap<Integer,String> chainhasmap = new ChainHashMap(5);
		chainhasmap.setLoad(2);
		chainhasmap.put(1, "item1");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(2, "item2");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(3, "item3");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(4, "item4");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(5, "item5");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(6, "item6");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(7, "item7");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(8, "item8");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(9, "item9");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(10, "item10");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(11, "item11");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(12, "item12");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
		chainhasmap.put(13, "item13");
		System.out.println("capacity: "+chainhasmap.capacity+" load: "+chainhasmap.size());
	      }
  
}
